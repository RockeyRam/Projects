<?php
	$con=mysql_connect("localhost","root","mysql","ProfileInfo");
	/*if (isset($con)) {
		# code...
		echo "Success";
	}
	else
	{
		echo "no";
	}*/
?>